mkdir OUTPUT/testout/
mkdir OUTPUT/testout/HS
mkdir OUTPUT/testout/HS/ALMS/
mkdir OUTPUT/testout/HS/KAPPA/
